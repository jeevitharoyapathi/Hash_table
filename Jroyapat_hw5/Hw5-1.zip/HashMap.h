#include "Interfaces05.h"
#include "KeyValue.h"

class  HashMap : public IHashMap{
public:
	int CurrSize = 0;
	std::vector<KeyValue *>  HashTable;
	int HashSize;
	HashMap();
	~HashMap() { }
	void insert(CompositeKey key, int value);
	void remove(CompositeKey key);
	bool containsKey(CompositeKey key);
	int getValue(CompositeKey key);
	int kthMinValue(int k);
	void insertintoTable(KeyValue *Kv, int index);
	unsigned long  GetIndex(CompositeKey key);
	int size();
	std::vector<CompositeKey> sort(std::vector<CompositeKey> input);
	int HPartition(int L, int R, std::vector<int> & Input);
	void RandomQuickSort(int L, int R, std::vector<int> & input);
	void Exchange(int I1, int I2, std::vector<int>& vec);
	void  QSort(int left, int right, std::vector<int>& vec);
};