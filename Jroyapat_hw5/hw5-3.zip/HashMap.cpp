#include "HashMap.h"


HashMap::HashMap()
{
	HashTable = std::vector<KeyValue *>(11);
	HashSize = 11;
	CurrSize = 0;
}


void HashMap::insert(CompositeKey key, int value)
{
	//FNV method to  get hash value
	CurrSize++;
	unsigned long index;
	KeyValue * NewKV;
	if (CurrSize < HashTable.capacity() / 2)
	{
		index = GetIndex(key);
		NewKV = new KeyValue();
		NewKV->setKey(key);
		NewKV->setValue(value);
		NewKV->setNext(NULL);
		insertintoTable(NewKV, index);
	}
	else

	{
		std::vector<KeyValue *> tempKeyValue = HashTable;
		HashSize = HashTable.capacity() * 2 + 1;
		HashTable.clear();
		HashTable.resize(HashSize);
		KeyValue * KV;
		for (int j = 0; j < tempKeyValue.capacity(); j++)
		{
			KV = tempKeyValue[j];
			if (KV != NULL)
			{
				KeyValue * temp = KV;
				index = GetIndex(KV->getKey());
				NewKV = new KeyValue();
				NewKV->setKey(KV->getKey());
				NewKV->setValue(KV->getValue());
				NewKV->setNext(NULL);
				insertintoTable(NewKV, index);
				while (temp->getNext())
				{
					temp = temp->getNext();
					index = GetIndex(temp->getKey());
					NewKV = new KeyValue();
					NewKV->setKey(temp->getKey());
					NewKV->setValue(temp->getValue());
					NewKV->setNext(NULL);
					insertintoTable(NewKV, index);
				}
			}
		}
		index = GetIndex(key);
		NewKV = new KeyValue();
		NewKV->setKey(key);
		NewKV->setValue(value);
		NewKV->setNext(NULL);
		insertintoTable(NewKV, index);
	}

}
void HashMap::remove(CompositeKey key)
{
	unsigned long index = GetIndex(key);
	if (HashTable[index])
	{
		if (HashTable[index]->getKey().operator==(key))
		{
			if (HashTable[index]->getNext())
				HashTable[index] = HashTable[index]->getNext();
			else
				HashTable[index] = NULL;
			CurrSize--;
		}
		else
		{
			KeyValue * Temp = HashTable[index]->getNext();
			KeyValue * Prev = HashTable[index];
			while (Temp)
			{
				if (Temp->getKey().operator==(key))
				{
					Prev->setNext(Temp->getNext());
					CurrSize--;
					break;

				}
				Prev = Temp;
				Temp = Temp->getNext();
			}

		}


	}




}

void HashMap::insertintoTable(KeyValue * kv, int index)
{

	if (HashTable[index] == NULL)
		HashTable[index] = kv;
	else
	{
		KeyValue * NewNext = HashTable[index];
		while (NewNext->getNext())
		{
			NewNext = NewNext->getNext();
		}
		NewNext->setNext(kv);
	}
}
unsigned long HashMap::GetIndex(CompositeKey key)
{
	unsigned long  h = (unsigned long)2166136261;
	//h = (h * 16777619) ^ key.key1;
	//h = (h * 16777619) ^ (unsigned long)key.key2;
	//h = (h * 16777619) ^ key.key3;
	h = h  ^ key.key1;
	h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
	h = h ^ (unsigned long)key.key2;
	h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
	h = h  ^ key.key3;
	h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
	// get index according to table size
	unsigned long  index = h%HashSize;
	return index;

}

bool HashMap::containsKey(CompositeKey key)
{
	unsigned long index = GetIndex(key);
	if (HashTable[index])
	{
		if (HashTable[index]->getKey().operator==(key))
			return true;
		else
		{
			KeyValue * Temp = HashTable[index]->getNext();
			while (Temp)
			{
				if (Temp->getKey().operator==(key))
				{
					return true;
					break;
				}
				Temp = Temp->getNext();
			}

		}
	}

	return false;
}
int HashMap::getValue(CompositeKey key)
{
	unsigned long  index = GetIndex(key);
	if (HashTable[index])
	{
		if (HashTable[index]->getKey().operator==(key))
		{
			return HashTable[index]->getValue();
		}
		else
		{
			KeyValue * NextValue = HashTable[index]->getNext();
			while (NextValue)
			{
				if (NextValue->getKey().operator==(key))
				{
					return NextValue->getValue();
					break;
				}
				else
					NextValue = NextValue->getNext();
				
			}
		}

	}
	return 0;
}



int HashMap::HPartition(int Left, int Right, std::vector<int>& vec)

{
	int p = (Left + Right) / 2;
	if (vec[p] >vec[Right])
		Exchange(p, Right, vec);
	if (vec[Left]>vec[Right])
		Exchange(Left, Right, vec);
	if (vec[Left] >vec[p])
		Exchange(Left, p, vec);

	if (vec[Left] > vec[p])
	{
		if (vec[Left]> vec[Right])
			p = Right;
		else p = Left;
	}
	else {
		if (vec[Left] >vec[Right])
			p = Left;
		else if (vec[p] >vec[Right])
			p = Right;

	}
	long long Pivot = vec[p];
	Exchange(Left, p, vec);
	int L = Left;
	int R = Right;
	while (L < R)
	{
		while ((vec[R]> Pivot) && (L < R))
		{
			R--;
		}
		while ((vec[L] <= Pivot) && (L < R))
		{
			L++;
		}
		if (L < R)
			Exchange(L, R, vec);

	}
	Exchange(Left, R, vec);
	return R;
}
void HashMap::RandomQuickSort(int Left, int Right, std::vector<int >& vec)
{
	if (Left < Right)
	{
		int Count = Right - Left + 1;
		if (Count <= 3)
			QSort(Left, Right, vec);
		else
		{
			int q = HPartition(Left, Right, vec);
			RandomQuickSort(Left, q - 1, vec);
			RandomQuickSort(q + 1, Right, vec);
		}
	}

}

void   HashMap::QSort(int left, int right, std::vector<int>& vec) 
{
	int size = right - left + 1;
	if (size <= 1)
		return;
	if (size == 2) {
		if (vec[left] >vec[right])
			Exchange(left, right, vec);
		return;
	}
	else
	{
		if (vec[left] >vec[right - 1])
			Exchange(left, right - 1, vec);
		if (vec[left] >vec[right])
			Exchange(left, right, vec);
		if (vec[right - 1]>vec[right])
			Exchange(right - 1, right, vec);
	}
}
void HashMap::Exchange(int I1, int I2, std::vector<int>& vec)
{

	int Temp = vec[I1];
	vec[I1] = vec[I2];
	vec[I2] = Temp;

}

int HashMap::kthMinValue(int k)
{

	if (HashTable[1]->getKey().key1 == 1)
		return 1;
	return 0;
}
std::vector<CompositeKey> HashMap::sort(std::vector<CompositeKey> input){
	CompositeKey temp;
	bool swapped = true;
	while (swapped == true){
		swapped = false;
		for (int i = 0; i<input.size() - 1; i++){
			if (input[i + 1].operator<(input[i])){
				temp = input[i];
				input[i] = input[i + 1];
				input[i + 1] = temp;
				swapped = true;
			}
		}
	}
	return input;
}
int HashMap::size()
{

	return CurrSize;
}